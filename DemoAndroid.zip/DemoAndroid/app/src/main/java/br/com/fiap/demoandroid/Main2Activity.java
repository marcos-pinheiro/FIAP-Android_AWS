package br.com.fiap.demoandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.parceler.Parcels;

public class Main2Activity extends AppCompatActivity {

    private TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        message = (TextView) findViewById(R.id.message);

        Parametros parametros = Parcels.unwrap(getIntent().getParcelableExtra("parametros"));
        message.setText(String.format("Bem vindo %s ao curso %s", parametros.getNome(), parametros.getEmail()));
    }
}
