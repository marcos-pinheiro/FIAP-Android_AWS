package br.com.fiap.demoandroid;

import org.parceler.Parcel;
import org.parceler.ParcelConstructor;

@Parcel
public class Parametros {

    private String nome;
    private String email;
    private String curso;

    @ParcelConstructor
    public Parametros(String nome, String email, String curso) {
        this.nome = nome;
        this.email = email;
        this.curso = curso;
    }

    public Parametros() {

    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCurso() {
        return curso;
    }

    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }
}
