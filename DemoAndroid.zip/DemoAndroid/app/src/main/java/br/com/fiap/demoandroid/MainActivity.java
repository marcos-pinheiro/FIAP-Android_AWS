package br.com.fiap.demoandroid;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import org.parceler.Parcels;

public class MainActivity extends AppCompatActivity {

    private EditText editNome;
    private EditText editEmail;
    private Spinner spinnerCurso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.editNome       = (EditText) findViewById(R.id.editNome);
        this.editEmail      = (EditText) findViewById(R.id.editEmail);
        this.spinnerCurso   = (Spinner) findViewById(R.id.spinnerCurso);
    }

    public void cadastrar(View view) {

        Parametros parametros = new Parametros(
            editNome.getText().toString(),
            editEmail.getText().toString(),
            spinnerCurso.getSelectedItem().toString()
        );

        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra("parametros", Parcels.wrap(parametros));
        startActivity(intent);
    }
}
